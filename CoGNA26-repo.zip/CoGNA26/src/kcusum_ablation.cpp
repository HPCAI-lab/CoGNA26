// KCUSUM arithmetic harness. Mirrors kcusum_posit_full.cpp operation by operation.
// Stage mask bits: 1=S1 input, 2=S2 kernel, 4=S3 increment, 8=S4 accumulation.
// mask 15 with format posit16/posit32 and mode "native" uses Universal posit types directly.
// Input file: first line "nstreams len", then one stream per line (whitespace separated).
// Usage: kcusum_ablation streams.txt delta1[,delta2,...]  > out.csv
#include <universal/number/posit/posit.hpp>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <functional>
#include <sstream>
#include <string>
#include <vector>
using namespace sw::universal;

static double r_fp64(double x) { return x; }
static double r_fp32(double x) { return (double)(float)x; }
static double r_fp16(double x) { return (double)(_Float16)x; }
static double r_bf16(double x) {  // round to nearest even, 8 significant bits, from double
    if (x == 0.0 || !std::isfinite(x)) return x;
    int e; double m = std::frexp(x, &e);           // x = m * 2^e, 0.5<=|m|<1
    double s = std::nearbyint(std::ldexp(m, 8));   // 8 significant bits incl. hidden
    return std::ldexp(s, e - 8);
}
static double r_p16(double x) { return (double)posit<16, 2>(x); }
static double r_p32(double x) { return (double)posit<32, 2>(x); }

using RF = double (*)(double);

// Generic run with per-stage rounding
static void run_mask(const std::vector<double>& z, double delta, RF rf, int mask, std::vector<double>& out) {
    auto R = [&](int bit, double v) { return (mask & bit) ? rf(v) : v; };
    auto gk = [&](double x, double y) {
        double d = R(2, x - y); double q = R(2, d * d); double e = R(2, -(q / R(2, 2.0)));
        return R(2, std::exp(e));
    };
    double Z = 0.0; out.clear();
    for (size_t i = 50; i < z.size(); ++i) {
        double a = R(1, z[i]), b = R(1, z[i - 1]), c = R(1, z[i % 50]);
        double xx = gk(a, b), yy = 1.0, xy = gk(a, c), yx = gk(b, c);
        double g = R(4, R(4, xx + yy) - R(4, xy + yx));
        double cc = R(4, g - R(4, delta));
        Z = R(8, Z + cc); if (Z < 0.0) Z = 0.0;
        out.push_back(Z);
    }
}

template <unsigned N, unsigned E>
static void run_posit_native(const std::vector<double>& z, double delta, std::vector<double>& out) {
    using P = posit<N, E>;
    auto gk = [](P x, P y) { P d = x - y; P q = d * d; P e = -(q / P(2.0)); return P(std::exp(static_cast<double>(e))); };
    P Z = 0.0; out.clear();
    for (size_t i = 50; i < z.size(); ++i) {
        P a = z[i], b = z[i - 1], c = z[i % 50];
        P xx = gk(a, b), yy = P(1.0), xy = gk(a, c), yx = gk(b, c);
        P av = (xx + yy) - (xy + yx);
        P cc = av - P(delta);
        Z = Z + cc; if (Z < P(0.0)) Z = 0.0;
        out.push_back((double)Z);
    }
}

int main(int argc, char** argv) {
    if (argc < 3) { std::fprintf(stderr, "usage: %s streams.txt deltas\n", argv[0]); return 2; }
    std::ifstream in(argv[1]); size_t ns, len; in >> ns >> len;
    std::vector<std::vector<double>> S(ns, std::vector<double>(len));
    for (auto& s : S) for (auto& v : s) in >> v;
    std::vector<double> deltas; { std::stringstream ss(argv[2]); std::string t; while (std::getline(ss, t, ',')) deltas.push_back(std::stod(t)); }
    struct F { const char* name; RF rf; int native; };
    F fmts[] = {{"FP64", r_fp64, 0}, {"FP32", r_fp32, 0}, {"FP16", r_fp16, 0}, {"BF16", r_bf16, 0}, {"Posit16", r_p16, 16}, {"Posit32", r_p32, 32}};
    int masks[] = {15, 1, 2, 4, 8};
    std::vector<double> out;
    std::printf("stream,delta,format,mode");
    for (size_t i = 50; i < len; ++i) std::printf(",t%zu", i);
    std::printf("\n");
    for (size_t si = 0; si < ns; ++si)
        for (double d : deltas)
            for (auto& f : fmts) {
                for (int m : masks) {
                    if (std::strcmp(f.name, "FP64") == 0 && m != 15) continue;
                    run_mask(S[si], d, f.rf, m, out);
                    std::printf("%zu,%.6g,%s,m%d", si, d, f.name, m);
                    for (double v : out) std::printf(",%.17g", v);
                    std::printf("\n");
                }
                if (f.native) {
                    if (f.native == 16) run_posit_native<16, 2>(S[si], d, out); else run_posit_native<32, 2>(S[si], d, out);
                    std::printf("%zu,%.6g,%s,native", si, d, f.name);
                    for (double v : out) std::printf(",%.17g", v);
                    std::printf("\n");
                }
            }
}
