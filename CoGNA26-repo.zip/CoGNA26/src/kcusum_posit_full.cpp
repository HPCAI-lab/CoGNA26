#include <universal/number/posit/posit.hpp>
#include <cmath>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <iomanip>
#include <iostream>
using namespace sw::universal;
template<unsigned N,unsigned E> using P=posit<N,E>;
template<unsigned N,unsigned E> P<N,E> gk(P<N,E> x,P<N,E> y){P<N,E>d=x-y;P<N,E>q=d*d;P<N,E>e=-(q/P<N,E>(2.0));return P<N,E>(std::exp(static_cast<double>(e)));}
template<unsigned N,unsigned E> P<N,E> mmd(P<N,E>a,P<N,E>b,P<N,E>c){P<N,E>xx=gk(a,b),yy=P<N,E>(1.0),xy=gk(a,c),yx=gk(b,c);return (xx+yy)-(xy+yx);}
template<unsigned N,unsigned E> void run(const std::vector<double>&z,const std::string&out){std::ofstream f(out);f<<"step,Z\n";P<N,E>Z=0.0;for(size_t i=50;i<z.size();++i){P<N,E>a=z[i],b=z[i-1],c=z[i%50];P<N,E>av=mmd(a,b,c);P<N,E>cc=av-P<N,E>(0.1);Z=Z+cc;if(Z<P<N,E>(0.0))Z=0.0;f<<i<<","<<std::setprecision(17)<<static_cast<double>(Z)<<"\n";}}
int main(int argc,char**argv){if(argc<2)return 2;std::ifstream in(argv[1]);std::vector<double>z;std::string line;while(std::getline(in,line)){if(line.empty())continue;std::stringstream ss(line);std::string a,b,c;if(!std::getline(ss,a,','))continue;if(!std::getline(ss,b,','))continue;if(!std::getline(ss,c,','))continue;z.push_back(std::stod(c));}run<16,2>(z,"posit16_full.csv");run<32,2>(z,"posit32_full.csv");}
