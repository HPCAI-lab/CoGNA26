"""Check that rounding a double-precision result to the target format equals the
correctly rounded target-format result, for +, -, *, / on FP32, FP16, BF16 operands.
Reference is exact rational arithmetic with round-to-nearest-even."""
import random, math
from fractions import Fraction
import numpy as np
def rne_exact(q, p, emin):
    if q == 0: return 0.0
    s = -1 if q < 0 else 1; a = abs(q)
    e = a.numerator.bit_length() - a.denominator.bit_length()
    if Fraction(2)**e > a: e -= 1
    e = max(e, emin)
    sc = Fraction(2)**(p-1-e); m = a*sc
    n = m.numerator // m.denominator; r = m - n
    if r > Fraction(1,2) or (r == Fraction(1,2) and n % 2): n += 1
    return s*float(Fraction(n)/sc)
def r_bf16(x):  # same as harness
    if x == 0.0 or not math.isfinite(x): return x
    m, e = math.frexp(x); return math.ldexp(round(math.ldexp(m, 8)), e-8)  # Python round = RNE
F = {'FP32': (lambda x: float(np.float32(x)), 24, -126),
     'FP16': (lambda x: float(np.float16(x)), 11, -14),
     'BF16': (r_bf16, 8, -126)}
OPS = {'+': lambda a,b: a+b, '-': lambda a,b: a-b, '*': lambda a,b: a*b, '/': lambda a,b: a/b}
random.seed(7); N = 200000
for name,(rf,p,emin) in F.items():
    hi = 6 if name == 'FP16' else 30
    bad = {o:0 for o in OPS}; n=0
    for i in range(N):
        # mix: workload-like magnitudes and wide random exponents
        if i % 2: a = rf(random.choice([188.0, 1.0, 0.1])*(1+random.uniform(-0.01,0.01))); b = rf(random.choice([188.0, 1.0, 0.1, 2.0])*(1+random.uniform(-0.01,0.01)))
        else: a = rf(random.uniform(1,2)*2.0**random.randint(-hi,hi)*random.choice([1,-1])); b = rf(random.uniform(1,2)*2.0**random.randint(-hi,hi)*random.choice([1,-1]))
        if b == 0: continue
        for o,f in OPS.items():
            ex = f(Fraction(a), Fraction(b)); ref = rne_exact(ex, p, emin)
            if abs(ref) > (65504 if name=='FP16' else 3e38): continue
            if rf(f(a,b)) != ref: bad[o] += 1
        n += 1
    print(f'{name}: {n} operand pairs x 4 ops, mismatches {bad}')
