"""Run the 1H9T stage ablation and the (delta, h) grid.

Usage: python3 run_1h9t.py mean_z.csv [--check artifact_results_dir] [--out PREFIX]
mean_z.csv is the same file passed to kcusum_posit (third column = mean z per frame).
If artifact_results_dir is given, the full-format trajectories are checked against
the published *_full.csv files first.
"""
import sys, subprocess, io, itertools
import numpy as np, pandas as pd

def _parse(path):  # mirrors kcusum_posit: skip blank lines, third comma field
    out = []
    for l in open(path):
        p = l.strip().split(',')
        if len(p) < 3: continue
        try: out.append(float(p[2]))
        except ValueError: pass   # header line
    return out
import argparse
ap = argparse.ArgumentParser(); ap.add_argument('stream'); ap.add_argument('--check'); ap.add_argument('--out', default='h9t')
A = ap.parse_args()
z = _parse(A.stream)
z = np.array(z)
print(f'frames {len(z)}  range [{z.min():.6g}, {z.max():.6g}]  '
      f'|x_t-x_t-1| range [{np.abs(np.diff(z)).min():.3g}, {np.abs(np.diff(z)).max():.3g}]  '
      f'|x_100 - x_99| {abs(z[100]-z[99]):.4g}')
DELTAS = [0.05, 0.1, 0.15, 0.2]
HS = [0.015, 0.1, 0.25, 0.5, 1.0]
with open(f'{A.out}_stream.txt', 'w') as f:
    f.write(f'1 {len(z)}\n' + ' '.join('%.17g' % v for v in z) + '\n')
out = subprocess.run(['./kcusum_ablation', f'{A.out}_stream.txt', ','.join(map(str, DELTAS))],
                     capture_output=True, text=True, check=True).stdout
d = pd.read_csv(io.StringIO(out))
tc = [c for c in d.columns if c.startswith('t')]; steps = np.array([int(c[1:]) for c in tc])
Z = d[tc].values
d = d.drop(columns=tc)
full = (d['mode'] == 'native') | ((d['mode'] == 'm15') & ~d.format.str.startswith('Posit'))
d['kind'] = np.where(full, 'full', d['mode'])
d = d[~((d['mode'] == 'm15') & d.format.str.startswith('Posit'))]
Z = Z[d.index]; d = d.reset_index(drop=True)

def T(zr, h):
    i = np.argmax(zr >= h); return int(steps[i]) if zr[i] >= h else None

if A.check:
    fn = {'FP64': 'fp64', 'FP32': 'fp32', 'FP16': 'fp16', 'BF16': 'bf16', 'Posit16': 'posit16', 'Posit32': 'posit32'}
    for f, n in fn.items():
        ref = pd.read_csv(f'{A.check}/{n}_full.csv')['Z'].values
        mine = Z[((d.format == f) & (d.kind == 'full') & (d.delta == 0.1)).values][0]
        print(f'check {f:8s} max |harness - artifact| = {np.abs(mine - ref).max():.3g}')

ref = {dl: Z[((d.format == 'FP64') & (d.delta == dl)).values][0] for dl in DELTAS}
rows = []
for i, r in d.iterrows():
    zr = Z[i]; z64 = ref[r.delta]
    rec = dict(delta=r.delta, format=r.format, kind=r.kind,
               e100=abs(zr[steps == 100][0] - z64[steps == 100][0]),
               Epostmax=np.abs(zr - z64)[steps > 100].max(), Epostmean=np.abs(zr - z64)[steps > 100].mean())
    for h in HS:
        rec[f'T{h}'] = T(zr, h); rec[f'ok{h}'] = T(zr, h) == T(z64, h)
    rows.append(rec)
R = pd.DataFrame(rows)
R.to_csv(f'{A.out}_results.csv', index=False)
pd.set_option('display.width', 200)
print('\nStage ablation at delta=0.1 (e100 and T at h=0.015):')
a = R[R.delta == 0.1]
print(a.pivot_table(index='format', columns='kind', values='e100').round(6))
print(a.pivot_table(index='format', columns='kind', values='T0.015', aggfunc='first'))
print('\nGrid: fraction of (delta,h) settings matching FP64 crossing frame, full format:')
g = R[R.kind == 'full']
g['okfrac'] = g[[f'ok{h}' for h in HS]].mean(axis=1)
print(g.groupby('format')['okfrac'].mean().round(3))
print(g.pivot_table(index='format', columns='delta', values='okfrac').round(2))
