import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
import os, sys; os.makedirs('figures', exist_ok=True); R=sys.argv[1] if len(sys.argv)>1 else 'results/published'
fn={'FP64':'fp64','FP32':'fp32','FP16':'fp16','BF16':'bf16','Posit16':'posit16','Posit32':'posit32'}
ST={ # color, linestyle, marker, lw, markevery offset
 'FP64':   ('#222222','-', None,2.4,0),
 'FP32':   ('#0072B2','--','s',1.4,0),
 'Posit32':('#AA4499',':','^',1.6,3),
 'FP16':   ('#D55E00','-', 'o',1.4,0),
 'Posit16':('#009E73','--','x',1.4,3),
 'BF16':   ('#8C6D00','-.','d',1.4,0)}
ORDER=['FP64','FP32','Posit32','FP16','Posit16','BF16']
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.color':'#e3e3e3','grid.linewidth':0.6,'legend.frameon':False})
Z={f:pd.read_csv(f'{R}/{fn[f]}_full.csv') for f in ORDER}
def sty(f,n=None,every=6):
    c,ls,m,lw,off=ST[f]; return dict(color=c,ls=ls,marker=m,lw=lw,ms=4.5,markevery=(off,every),mfc='none' if m in('s','^','o','d') else c,label=f)
W=(4.8,2.9)
# Fig error: two panels, 16-bit and 32-bit
fig,axs=plt.subplots(1,2,figsize=(6.2,2.6),sharex=True)
for ax,grp,ttl in [(axs[0],['FP16','Posit16','BF16'],'16-bit formats'),(axs[1],['FP32','Posit32'],'32-bit formats')]:
    for f in grp:
        d=Z[f]; e=(d.Z-Z['FP64'].Z).abs(); m=d.step>=100
        ax.plot(d.step[m],e[m],**sty(f,every=5))
    ax.set_yscale('log'); ax.set_xlabel('Frame'); ax.set_title(ttl,fontsize=9); ax.set_xlim(99,151)
    ax.legend(loc='lower right',fontsize=7.5,handlelength=2.6)
axs[0].set_ylabel(r'$|e_t|$ (deviation from FP64)')
fig.tight_layout(); [fig.savefig(f'figures/fig2_deviation.{x}',dpi=300) for x in ('png','pdf')]
# Fig 2 trajectories
fig,ax=plt.subplots(figsize=W)
for f in ORDER:
    d=Z[f]; ax.plot(d.step,d.Z,**sty(f,every=8))
ax.axhline(0.015,color='#555555',ls=(0,(4,2)),lw=0.9); ax.axvline(100,color='#555555',ls=':',lw=0.9)
ax.annotate('$h=0.015$',(52,0.015),xytext=(52,0.55),fontsize=8,color='#444444',arrowprops=dict(arrowstyle='-',color='#888888',lw=0.6))
ax.text(101,6.3,'FP64 detection\nframe 100',fontsize=8,color='#444444',va='top')
ax.set_xlabel('Frame'); ax.set_ylabel(r'$Z_t$'); ax.set_xlim(49,151)
ax.legend(ncol=2,loc='upper left',fontsize=8,bbox_to_anchor=(0,0.82))
fig.tight_layout(); [fig.savefig(f'figures/fig1_trajectories.{x}',dpi=300) for x in ('png','pdf')]
# Fig 3 threshold sweep
s=pd.read_csv(f'{R}/threshold_sweep_wide.csv'); s['threshold']=s.threshold.round(6); s=s.drop_duplicates('threshold')
fig,ax=plt.subplots(figsize=W)
for f in ORDER:
    y=s[f].astype(float).where(s[f]>0)
    kw=sty(f,every=4)
    if f=='BF16': kw['label']='BF16 (no detection)'; ax.plot([],[],**kw); continue
    ax.plot(s.threshold,y,drawstyle='steps-post',**kw)
ax.axvline(0.015,color='#555555',ls=(0,(4,2)),lw=0.9,label='nominal $h=0.015$')
ax.set_xlabel('Threshold $h$'); ax.set_ylabel('First crossing frame'); ax.set_xlim(-0.1,7.1)
ax.legend(ncol=2,loc='lower right',fontsize=8)
fig.tight_layout(); [fig.savefig(f'figures/fig3_threshold_sweep.{x}',dpi=300) for x in ('png','pdf')]
