"""Center the mean-z stream on the mean of the reference frames 0-49, in double precision.
Usage: python3 center_stream.py mean_z.csv mean_z_centered.csv"""
import sys
rows = [l.strip().split(',') for l in open(sys.argv[1]) if l.strip()]
z = [float(r[2]) for r in rows]
m = sum(z[:50]) / 50.0
with open(sys.argv[2], 'w') as f:
    for r, v in zip(rows, z):
        f.write(f'{r[0]},{r[1]},{v - m!r}\n')
