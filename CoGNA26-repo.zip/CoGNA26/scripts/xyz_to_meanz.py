import sys, numpy as np
lines=open(sys.argv[1]).read().split('\n')
i=0; out=[]
while i < len(lines):
    if not lines[i].strip(): i+=1; continue
    n=int(lines[i].split()[0]); block=lines[i+2:i+2+n]
    if len(block)<n or any(len(l.split())<4 for l in block): print('incomplete frame at',len(out),'excluded'); break
    z=np.array([float(l.split()[3]) for l in block]); out.append(z.mean()); i+=2+n
with open(sys.argv[2],'w') as f:
    for k,v in enumerate(out): f.write(f'{k},{n},{float(v)!r}\n')
print(len(out),'frames')
