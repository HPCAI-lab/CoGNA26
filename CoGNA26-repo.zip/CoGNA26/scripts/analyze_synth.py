import numpy as np, pandas as pd
d=pd.read_csv('synth_out.csv'); meta=pd.read_csv('synth_meta.csv')
tc=[c for c in d.columns if c.startswith('t')]; steps=np.array([int(c[1:]) for c in tc])
Z=d[tc].values
def T(z,h):
    i=np.argmax(z>=h); return steps[i] if z[i]>=h else -1
d=d.drop(columns=tc).merge(meta,on='stream')
# native vs mask15
for p in ['Posit16','Posit32']:
    a=Z[(d.format==p)&(d['mode']=='native')]; b=Z[(d.format==p)&(d['mode']=='m15')]
    print(p,'native vs m15 max abs diff',np.abs(a-b).max(), 'identical rows',np.mean(np.all(a==b,axis=1)))
H=[0.015,0.25,1.0]
for h in H: d[f'T{h}']=[T(z,h) for z in Z]
ref=d[d.format=='FP64'].set_index('stream')
d=d.join(ref[[f'T{h}' for h in H]],on='stream',rsuffix='_64')
for h in H: d[f'ok{h}']=d[f'T{h}']==d[f'T{h}_64']
d['okall']=d[[f'ok{h}' for h in H]].all(axis=1)
d['e100']=np.abs(Z[:,steps==100][:,0]-ref.loc[d.stream].values[:,0]*0+Z[d.stream.map(lambda s: ref.index.get_loc(s)).values*0,0]*0) # placeholder
full=d[d['mode'].isin(['m15']) | ((d['mode']=='native'))]
full=full[~((full.format.str.startswith('Posit'))&(full['mode']=='m15'))]
print('\nFP64 detections at h=0.015 by c,dmu (fraction detecting at 100):')
r=d[d.format=='FP64']; print(r.groupby(['c','dmu'])['T0.015'].apply(lambda s:(s==100).mean()).unstack())
print('\nDecision preservation (all three h), full format, by c (rows) x format:')
print(full.groupby(['c','format'])['okall'].mean().unstack().round(2))
print('\nAt h=0.015 by dmu for c=160:')
print(full[full.c==160].groupby(['dmu','format'])['ok0.015'].mean().unstack().round(2))
print('\nAt h=0.015 by dmu for c=40:')
print(full[full.c==40].groupby(['dmu','format'])['ok0.015'].mean().unstack().round(2))
print('\nOverall fraction preserved (all h, all c, dmu):'); print(full.groupby('format')['okall'].mean().round(3))
ab=d[d['mode'].isin(['m1','m2','m4','m8'])]
print('\nAblation: fraction preserved (all h) by stage, c=160'); print(ab[ab.c==160].groupby(['format','mode'])['okall'].mean().unstack().round(2))
print('\nAblation: fraction preserved (all h) by stage, all c'); print(ab.groupby(['format','mode'])['okall'].mean().unstack().round(2))
d.to_pickle('synth_dec.pkl')
