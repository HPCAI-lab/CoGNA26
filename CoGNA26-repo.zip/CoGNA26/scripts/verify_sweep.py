# Usage: python3 verify_sweep.py <published results dir> <h9t_stream.txt from run_1h9t.py>
# Recomputes every crossing frame in threshold_sweep_wide.csv from the harness and reports mismatches.
import numpy as np, pandas as pd, subprocess, io
import sys; R=sys.argv[1]; STREAM=sys.argv[2]
sw=pd.read_csv(f'{R}/threshold_sweep_wide.csv'); sw=sw[sw.threshold<=7.0]
# harness trajectories at delta=0.1 (raw stream)
out=subprocess.run(['./kcusum_ablation',STREAM,'0.1'],capture_output=True,text=True,check=True).stdout
d=pd.read_csv(io.StringIO(out)); tc=[c for c in d.columns if c.startswith('t')]; steps=np.array([int(c[1:]) for c in tc])
sel={'FP64':('FP64','m15'),'FP32':('FP32','m15'),'FP16':('FP16','m15'),'BF16':('BF16','m15'),'Posit16':('Posit16','native'),'Posit32':('Posit32','native')}
Z={k:d[(d.format==f)&(d['mode']==m)][tc].values[0] for k,(f,m) in sel.items()}
def T(z,h):
    i=np.argmax(z>=h); return int(steps[i]) if z[i]>=h else 0
mism=0
for _,r in sw.iterrows():
    for f in sel:
        if T(Z[f],r.threshold)!=int(r[f]): mism+=1; print('mismatch',r.threshold,f,T(Z[f],r.threshold),r[f])
print('sweep rows',len(sw),'; harness vs published sweep mismatches:',mism)
u=sw.assign(h=sw.threshold.round(6)).drop_duplicates('h')
print('distinct thresholds',len(u),'(the file lists h=1.0 twice)')
for f in ['FP16','Posit16','BF16','FP32','Posit32']:
    d=u[u[f]!=u.FP64]; both=d[(d.FP64>0)&(d[f]>0)]
    print(f'{f:8s} differs at {len(d):2d}  displaced {len(both):2d}  detection disagreement {len(d)-len(both):2d}')
print('Table6 check:'); 
for h in [0.005,0.015,0.25,1.0,2.0,5.0]: print(h,{f:T(Z[f],h) for f in sel})
