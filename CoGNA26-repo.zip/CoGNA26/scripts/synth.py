import numpy as np, subprocess, pandas as pd, io, itertools, sys
rng=np.random.default_rng(2026)
C=[0.5,6.0,40.0,160.0]; DM=[0.1,0.2,0.3,0.45,0.6,0.8,1.0]; SEEDS=20; SIG=0.01; L=151
meta=[];S=[]
for c,dm,s in itertools.product(C,DM,range(SEEDS)):
    x=c+SIG*rng.standard_normal(L); x[100:]+=dm; S.append(x); meta.append((c,dm,s))
with open('synth_streams.txt','w') as f:
    f.write(f"{len(S)} {L}\n"); [f.write(' '.join('%.17g'%v for v in x)+'\n') for x in S]
pd.DataFrame(meta,columns=['c','dmu','seed']).to_csv('synth_meta.csv',index_label='stream')
out=subprocess.run(['./kcusum_ablation','synth_streams.txt','0.1'],capture_output=True,text=True,check=True).stdout
open('synth_out.csv','w').write(out)
